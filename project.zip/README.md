# Bozdar Virus Cleaner — v1.0.0+1

Asal phone safai + virus scan app (Android / OnePlus). **Koi jhoota virus nahi.**

## Kya karta hai (asal)
- Installed apps ki list (`device_apps`) + har app ki permissions, installer
  aur device-admin haalat (Kotlin MethodChannel `com.bozdar.viruscleaner/native`).
- Risk jaanch (`lib/risk.dart`, pure Dart, unit-tested):
  - mashhoor kharab packages (Zscaler ThreatLabz / CSIS ki Joker reports),
  - khatarnak permissions (SMS, call log, overlay, device admin, install-packages),
  - Play Store se install na hona.
- Apni cache ka size + safai; Downloads/DCIM mein 100 MB se bari files aur
  duplicate-shak files.
- Scan / alert / safai ki awaazein (`assets/sounds/`, ffmpeg se bani hain).
- Scan animation mein virus ke nishan shield ki taraf khinchte dikhte hain —
  **ye sirf visual hai**, code aur UI dono mein saaf likha hai.

## Imaandari ke usool (lock)
- Kuch na mile to natija: **"Koi virus nahi mila"** — kabhi fake virus nahi.
- Koi "100% virus-free guarantee" nahi — ye antivirus engine nahi hai.
- Uninstall hamesha Android ki system screen se, user khud confirm karke
  karega (Android kisi app ko bina user ki haan ke doosri app delete karne
  nahi deta). Doosri apps ki cache hum saaf nahi kar sakte — sirf apni cache;
  baqi ke liye App Info khulta hai.

## Build
- Flutter 3.24.5, minSdk 23, package `com.bozdar.viruscleaner`
  (MainActivity package == applicationId).
- Version: pubspec `1.0.0+1` == `lib/version.dart` kAppVersionCode 1.
- Verify: `flutter analyze` (0 issues) + `flutter test` (8 pass) +
  `flutter build bundle` (kernel_blob.bin).
- CI: project.zip upload → Flutter build → APK. Signing parent ke paas.
