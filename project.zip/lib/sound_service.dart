import 'package:audioplayers/audioplayers.dart';

/// Scan / alert / safai ki awaazein.
///
/// Files: assets/sounds/scan.wav, alert.wav, clean.wav
/// (ffmpeg se banai gayi hain — koi copyright wali awaaz nahi.)
/// Awaaz na baje to app rukegi nahi — har ghalti khamoshi se nigal li jati hai.
class SoundService {
  SoundService._();
  static final SoundService instance = SoundService._();

  final AudioPlayer _player = AudioPlayer();

  Future<void> playScan() => _play('sounds/scan.wav');
  Future<void> playAlert() => _play('sounds/alert.wav');
  Future<void> playClean() => _play('sounds/clean.wav');

  Future<void> _play(String asset) async {
    try {
      await _player.stop();
      await _player.play(AssetSource(asset));
    } catch (_) {
      // Awaaz na ho to bhi kaam chalta rahe.
    }
  }

  Future<void> dispose() async {
    try {
      await _player.dispose();
    } catch (_) {}
  }
}
