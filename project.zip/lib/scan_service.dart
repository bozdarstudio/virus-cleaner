import 'dart:io';

import 'package:path_provider/path_provider.dart';

import 'native.dart';
import 'risk.dart';

/// Storage mein mili file (badi ya duplicate).
class FoundFile {
  const FoundFile({required this.path, required this.sizeBytes});

  final String path;
  final int sizeBytes;

  String get name => path.split('/').last;
}

/// Ek mukammal scan ka natija — jo mila, wahi dikhana hai. Kuch na mile to
/// lists khaali hongi aur UI imaandari se "Koi virus nahi mila" likhega.
class ScanReport {
  const ScanReport({
    required this.totalApps,
    required this.dangerous,
    required this.suspicious,
    required this.safeCount,
    required this.ownCacheBytes,
    required this.largeFiles,
    required this.duplicateGroups,
    required this.scannedAt,
  });

  final int totalApps;
  final List<ScannedApp> dangerous;
  final List<ScannedApp> suspicious;
  final int safeCount;

  /// Sirf is app ki apni cache — doosri apps ki cache Android humein
  /// dekhne/saaf karne nahi deta. UI mein ye saaf likha hai.
  final int ownCacheBytes;

  /// 100 MB se bari files (Downloads / DCIM / Pictures mein).
  final List<FoundFile> largeFiles;

  /// Aik jaise size wali files ke group (Downloads mein) — duplicate shak.
  final List<List<FoundFile>> duplicateGroups;

  final DateTime scannedAt;

  int get flaggedCount => dangerous.length + suspicious.length;
  bool get foundAnything =>
      flaggedCount > 0 || largeFiles.isNotEmpty || duplicateGroups.isNotEmpty;
}

/// Scan + safai ka asal kaam.
class ScanService {
  /// Mukammal scan. `onProgress` har app par bulaaya jata hai taake UI
  /// dikha sake ke asal mein kaam ho raha hai.
  static Future<ScanReport> runScan({
    void Function(int done, int total, String appName)? onProgress,
    bool scanFiles = true,
  }) async {
    // Installed apps ki list — ab apne MethodChannel se (device_apps
    // plugin hata diya gaya: us ke android/build.gradle mein namespace
    // nahi tha, AGP 8.1 par CI fail hota tha).
    final apps = await NativeChannel.getInstalledApps();

    final dangerous = <ScannedApp>[];
    final suspicious = <ScannedApp>[];
    var safe = 0;

    for (var i = 0; i < apps.length; i++) {
      final app = apps[i];
      onProgress?.call(i + 1, apps.length, app.appName);

      final info = await NativeChannel.getAppDetails(app.packageName);
      final apkSize = await _fileSize(app.apkFilePath);

      final scanned = assessApp(
        packageName: app.packageName,
        appName: app.appName,
        systemApp: app.systemApp,
        installer: info.installer,
        permissions: info.permissions,
        deviceAdmin: info.deviceAdmin,
        apkSizeBytes: apkSize,
      );

      switch (scanned.risk) {
        case RiskLevel.dangerous:
          dangerous.add(scanned);
        case RiskLevel.suspicious:
          suspicious.add(scanned);
        case RiskLevel.safe:
          safe++;
      }
    }

    final ownCache = await ownCacheSize();

    var large = <FoundFile>[];
    var dups = <List<FoundFile>>[];
    if (scanFiles) {
      final found = await scanPublicFiles();
      large = found.large;
      dups = found.duplicates;
    }

    return ScanReport(
      totalApps: apps.length,
      dangerous: dangerous,
      suspicious: suspicious,
      safeCount: safe,
      ownCacheBytes: ownCache,
      largeFiles: large,
      duplicateGroups: dups,
      scannedAt: DateTime.now(),
    );
  }

  /// Is app ki apni cache + temp ka size.
  static Future<int> ownCacheSize() async {
    var total = 0;
    for (final dir in await _ownCacheDirs()) {
      total += await _dirSize(dir);
    }
    return total;
  }

  /// Apni cache/temp khaali karo. Wapas: asal mein kitne bytes saaf hue.
  /// (Sirf wahi ginna jo waqai delete hua — jhoot nahi.)
  static Future<int> cleanOwnCache() async {
    var freed = 0;
    for (final dir in await _ownCacheDirs()) {
      if (!await dir.exists()) continue;
      await for (final e in dir.list(recursive: true, followLinks: false)) {
        try {
          final size = e is File ? await e.length() : 0;
          await e.delete(recursive: true);
          freed += size;
        } catch (_) {
          // Koi file delete na ho to chup chaap chhor do — ginti mein nahi.
        }
      }
    }
    return freed;
  }

  /// Files delete karne ki koshish karo (badi/duplicate files).
  /// Wapas: asal mein kitne bytes saaf hue.
  static Future<int> deleteFiles(List<FoundFile> files) async {
    var freed = 0;
    for (final f in files) {
      try {
        final file = File(f.path);
        if (await file.exists()) {
          final size = await file.length();
          await file.delete();
          freed += size;
        }
      } catch (_) {
        // Android 13+ par shared storage ki files delete nahi ho sakti —
        // user ko App Info se karna parega. Jhoot nahi bolna.
      }
    }
    return freed;
  }

  static Future<List<Directory>> _ownCacheDirs() async {
    final dirs = <Directory>[];
    try {
      dirs.add(await getTemporaryDirectory());
    } catch (_) {}
    try {
      dirs.add(await getApplicationCacheDirectory());
    } catch (_) {}
    return dirs;
  }

  static Future<int> _fileSize(String path) async {
    try {
      return await File(path).length();
    } catch (_) {
      return 0;
    }
  }

  static Future<int> _dirSize(Directory dir) async {
    var total = 0;
    if (!await dir.exists()) return 0;
    try {
      await for (final e in dir.list(recursive: true, followLinks: false)) {
        if (e is File) {
          try {
            total += await e.length();
          } catch (_) {}
        }
      }
    } catch (_) {}
    return total;
  }

  /// Public folders mein badi files + duplicate-shak files dhoondo.
  static Future<({List<FoundFile> large, List<List<FoundFile>> duplicates})>
      scanPublicFiles() async {
    const largeThreshold = 100 * 1024 * 1024; // 100 MB
    final large = <FoundFile>[];
    final bySize = <int, List<FoundFile>>{};

    final roots = <Directory>[];
    for (final name in ['Download', 'DCIM', 'Pictures', 'Movies']) {
      final dir = Directory('/storage/emulated/0/$name');
      if (await dir.exists()) roots.add(dir);
    }

    for (final root in roots) {
      try {
        await for (final e
            in root.list(recursive: true, followLinks: false)) {
          if (e is! File) continue;
          int size;
          try {
            size = await e.length();
          } catch (_) {
            continue;
          }
          final found = FoundFile(path: e.path, sizeBytes: size);
          if (size >= largeThreshold) large.add(found);
          // Sirf Downloads mein duplicates dekhte hain.
          if (root.path.endsWith('/Download')) {
            bySize.putIfAbsent(size, () => []).add(found);
          }
        }
      } catch (_) {}
    }

    large.sort((a, b) => b.sizeBytes.compareTo(a.sizeBytes));
    final dups = bySize.values
        .where((g) => g.length > 1 && g.first.sizeBytes > 1024 * 1024)
        .toList()
      ..sort((a, b) => b.first.sizeBytes.compareTo(a.first.sizeBytes));

    return (large: large.take(20).toList(), duplicates: dups.take(10).toList());
  }
}
