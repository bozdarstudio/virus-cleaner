import 'dart:io';

import 'package:path_provider/path_provider.dart';

import 'native.dart';
import 'risk.dart';

/// Ek mukammal scan ka natija — jo mila, wahi dikhana hai. Kuch na mile to
/// lists khaali hongi aur UI imaandari se "Koi virus nahi mila" likhega.
///
/// NOTE: Is report mein user ki zaati files (videos/tasveerein/documents)
/// ka koi zikr NAHI hai — ye app zaati files ko na scan karti hai, na
/// kabhi delete karti hai. Sirf installed apps ki jaanch hoti hai.
class ScanReport {
  const ScanReport({
    required this.totalApps,
    required this.dangerous,
    required this.suspicious,
    required this.safeCount,
    required this.ownCacheBytes,
    required this.scannedAt,
  });

  final int totalApps;
  final List<ScannedApp> dangerous;
  final List<ScannedApp> suspicious;
  final int safeCount;

  /// Sirf is app ki apni cache — doosri apps ki cache Android humein
  /// dekhne/saaf karne nahi deta. UI mein ye saaf likha hai.
  final int ownCacheBytes;

  final DateTime scannedAt;

  int get flaggedCount => dangerous.length + suspicious.length;
  bool get foundAnything => flaggedCount > 0;
}

/// Scan + safai ka asal kaam.
class ScanService {
  /// Mukammal scan. HAR installed app cover hoti hai — system apps aur
  /// Play Store ke bahir se install hui (sideloaded) apps sameet.
  /// `onProgress` har app par bulaaya jata hai taake UI dikha sake ke
  /// asal mein kaam ho raha hai.
  static Future<ScanReport> runScan({
    void Function(int done, int total, String appName)? onProgress,
  }) async {
    // Installed apps ki list — ab apne MethodChannel se (device_apps
    // plugin hata diya gaya: us ke android/build.gradle mein namespace
    // nahi tha, AGP 8.1 par CI fail hota tha).
    final apps = await NativeChannel.getInstalledApps();

    final dangerous = <ScannedApp>[];
    final suspicious = <ScannedApp>[];
    var safe = 0;

    for (var i = 0; i < apps.length; i++) {
      final app = apps[i];
      onProgress?.call(i + 1, apps.length, app.appName);

      final info = await NativeChannel.getAppDetails(app.packageName);
      final apkSize = await _fileSize(app.apkFilePath);

      final scanned = assessApp(
        packageName: app.packageName,
        appName: app.appName,
        systemApp: app.systemApp,
        installer: info.installer,
        permissions: info.permissions,
        deviceAdmin: info.deviceAdmin,
        apkSizeBytes: apkSize,
      );

      switch (scanned.risk) {
        case RiskLevel.dangerous:
          dangerous.add(scanned);
        case RiskLevel.suspicious:
          suspicious.add(scanned);
        case RiskLevel.safe:
          safe++;
      }
    }

    final ownCache = await ownCacheSize();

    return ScanReport(
      totalApps: apps.length,
      dangerous: dangerous,
      suspicious: suspicious,
      safeCount: safe,
      ownCacheBytes: ownCache,
      scannedAt: DateTime.now(),
    );
  }

  /// Is app ki apni cache + temp ka size.
  static Future<int> ownCacheSize() async {
    var total = 0;
    for (final dir in await _ownCacheDirs()) {
      total += await _dirSize(dir);
    }
    return total;
  }

  /// Apni cache/temp khaali karo. Wapas: asal mein kitne bytes saaf hue.
  /// (Sirf wahi ginna jo waqai delete hua — jhoot nahi.)
  static Future<int> cleanOwnCache() async {
    var freed = 0;
    for (final dir in await _ownCacheDirs()) {
      if (!await dir.exists()) continue;
      await for (final e in dir.list(recursive: true, followLinks: false)) {
        try {
          final size = e is File ? await e.length() : 0;
          await e.delete(recursive: true);
          freed += size;
        } catch (_) {
          // Koi file delete na ho to chup chaap chhor do — ginti mein nahi.
        }
      }
    }
    return freed;
  }

  static Future<List<Directory>> _ownCacheDirs() async {
    final dirs = <Directory>[];
    try {
      dirs.add(await getTemporaryDirectory());
    } catch (_) {}
    try {
      dirs.add(await getApplicationCacheDirectory());
    } catch (_) {}
    return dirs;
  }

  static Future<int> _fileSize(String path) async {
    try {
      return await File(path).length();
    } catch (_) {
      return 0;
    }
  }

  static Future<int> _dirSize(Directory dir) async {
    var total = 0;
    if (!await dir.exists()) return 0;
    try {
      await for (final e in dir.list(recursive: true, followLinks: false)) {
        if (e is File) {
          try {
            total += await e.length();
          } catch (_) {}
        }
      }
    } catch (_) {}
    return total;
  }
}
