import 'package:flutter/services.dart';

/// Native Android (Kotlin) se baat — PackageManager ki asal maloomat.
///
/// Channel: `com.bozdar.viruscleaner/native`
/// Method: `getAppDetails` — har app ke liye:
///   - `permissions`: mangi gayi permissions ki list
///   - `installer`: kis app ne install kiya (null = pata nahi)
///   - `deviceAdmin`: kya ye app device admin hai
class NativeInfo {
  const NativeInfo({
    required this.permissions,
    required this.installer,
    required this.deviceAdmin,
  });

  final List<String> permissions;
  final String? installer;
  final bool deviceAdmin;

  factory NativeInfo.empty() =>
      const NativeInfo(permissions: [], installer: null, deviceAdmin: false);

  factory NativeInfo.fromMap(Map<dynamic, dynamic> map) {
    final perms = (map['permissions'] as List?)?.cast<String>() ?? <String>[];
    return NativeInfo(
      permissions: perms,
      installer: map['installer'] as String?,
      deviceAdmin: map['deviceAdmin'] as bool? ?? false,
    );
  }
}

class NativeChannel {
  static const _channel =
      MethodChannel('com.bozdar.viruscleaner/native');

  /// Ek app ki tafseel lo. Ghalti par khaali maloomat (scan rukega nahi).
  static Future<NativeInfo> getAppDetails(String packageName) async {
    try {
      final result = await _channel.invokeMethod<Map<dynamic, dynamic>>(
        'getAppDetails',
        {'packageName': packageName},
      );
      if (result == null) return NativeInfo.empty();
      return NativeInfo.fromMap(result);
    } on PlatformException {
      return NativeInfo.empty();
    } on MissingPluginException {
      return NativeInfo.empty();
    }
  }

  /// Saari installed apps ki list lo (system apps samet).
  /// Ghalti par khaali list (scan rukega nahi).
  static Future<List<InstalledApp>> getInstalledApps() async {
    try {
      final result = await _channel.invokeMethod<List<dynamic>>(
        'getInstalledApps',
      );
      if (result == null) return <InstalledApp>[];
      return result
          .whereType<Map<dynamic, dynamic>>()
          .map(InstalledApp.fromMap)
          .toList();
    } on PlatformException {
      return <InstalledApp>[];
    } on MissingPluginException {
      return <InstalledApp>[];
    }
  }

  /// System uninstall screen kholo — user khud confirm karega.
  /// Android kisi app ko bina user ki haan ke doosri app delete
  /// karne nahi deta; is liye ye sirf screen kholta hai.
  static Future<bool> uninstallApp(String packageName) async {
    try {
      final result = await _channel.invokeMethod<bool>(
        'uninstallApp',
        {'packageName': packageName},
      );
      return result ?? false;
    } on PlatformException {
      return false;
    } on MissingPluginException {
      return false;
    }
  }

  /// App Info (system settings) kholo — wahan se cache saaf kar sakte hain.
  static Future<bool> openAppSettings(String packageName) async {
    try {
      final result = await _channel.invokeMethod<bool>(
        'openAppSettings',
        {'packageName': packageName},
      );
      return result ?? false;
    } on PlatformException {
      return false;
    } on MissingPluginException {
      return false;
    }
  }
}

/// Ek installed app — PackageManager se asal maloomat.
class InstalledApp {
  const InstalledApp({
    required this.packageName,
    required this.appName,
    required this.systemApp,
    required this.apkFilePath,
  });

  final String packageName;
  final String appName;
  final bool systemApp;
  final String apkFilePath;

  factory InstalledApp.fromMap(Map<dynamic, dynamic> map) {
    return InstalledApp(
      packageName: map['packageName'] as String? ?? '',
      appName: map['appName'] as String? ?? '',
      systemApp: map['systemApp'] as bool? ?? false,
      apkFilePath: map['apkFilePath'] as String? ?? '',
    );
  }
}
