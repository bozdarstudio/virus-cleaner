import 'package:flutter/services.dart';

/// Native Android (Kotlin) se baat — PackageManager ki asal maloomat.
///
/// Channel: `com.bozdar.viruscleaner/native`
/// Method: `getAppDetails` — har app ke liye:
///   - `permissions`: mangi gayi permissions ki list
///   - `installer`: kis app ne install kiya (null = pata nahi)
///   - `deviceAdmin`: kya ye app device admin hai
class NativeInfo {
  const NativeInfo({
    required this.permissions,
    required this.installer,
    required this.deviceAdmin,
  });

  final List<String> permissions;
  final String? installer;
  final bool deviceAdmin;

  factory NativeInfo.empty() =>
      const NativeInfo(permissions: [], installer: null, deviceAdmin: false);

  factory NativeInfo.fromMap(Map<dynamic, dynamic> map) {
    final perms = (map['permissions'] as List?)?.cast<String>() ?? <String>[];
    return NativeInfo(
      permissions: perms,
      installer: map['installer'] as String?,
      deviceAdmin: map['deviceAdmin'] as bool? ?? false,
    );
  }
}

class NativeChannel {
  static const _channel =
      MethodChannel('com.bozdar.viruscleaner/native');

  /// Ek app ki tafseel lo. Ghalti par khaali maloomat (scan rukega nahi).
  static Future<NativeInfo> getAppDetails(String packageName) async {
    try {
      final result = await _channel.invokeMethod<Map<dynamic, dynamic>>(
        'getAppDetails',
        {'packageName': packageName},
      );
      if (result == null) return NativeInfo.empty();
      return NativeInfo.fromMap(result);
    } on PlatformException {
      return NativeInfo.empty();
    } on MissingPluginException {
      return NativeInfo.empty();
    }
  }
}
