/// App ka version — pubspec.yaml ke `version: 1.0.0+1` se barabar lazmi.
///
/// Har release se pehle check: `grep kAppVersionCode lib/version.dart`
/// == pubspec ka `+N`. Match na ho to build mat bhejo.
const String kAppVersion = '1.0.0';
const int kAppVersionCode = 1;
