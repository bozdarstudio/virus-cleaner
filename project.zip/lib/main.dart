import 'dart:math' as math;

import 'package:device_apps/device_apps.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

import 'risk.dart';
import 'scan_service.dart';
import 'sound_service.dart';
import 'version.dart';

// ---------------------------------------------------------------------------
// Bozdar Virus Cleaner v1.0.0
//
// IMAANDARI KA LOCK:
// - Ye app asal scan karti hai: installed apps + un ki permissions +
//   mashhoor kharab packages ki fehrist + badi/duplicate files.
// - Ye koi "antivirus engine" NAHI hai. UI mein kahin bhi "100% virus-free"
//   ya koi guarantee NAHI likhni.
// - Agar kuch na mile to natija hai "Koi virus nahi mila". Kabhi jhooti
//   ginti ya fake virus NAHI dikhana.
// - Android ka rule: koi app bina user ki haan ke doosri app delete NAHI
//   kar sakti. Is liye uninstall hamesha system ki screen se, user khud
//   confirm karke karega. Doosri apps ki cache bhi hum saaf nahi kar sakte —
//   sirf apni cache saaf hoti hai; baqi ke liye App Info khulta hai.
// ---------------------------------------------------------------------------

void main() {
  runApp(const VirusCleanerApp());
}

class VirusCleanerApp extends StatelessWidget {
  const VirusCleanerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Virus Cleaner',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF1B5E20), // gehra sabz
          primary: const Color(0xFF1B5E20),
          secondary: const Color(0xFFC9A227), // sunehri
        ),
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF4F8F4),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF1B5E20),
          foregroundColor: Colors.white,
          centerTitle: true,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF1B5E20),
            foregroundColor: Colors.white,
            padding:
                const EdgeInsets.symmetric(horizontal: 28, vertical: 16),
            textStyle:
                const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
        ),
      ),
      home: const HomePage(),
    );
  }
}

enum _Phase { home, scanning, result }

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage>
    with SingleTickerProviderStateMixin {
  _Phase _phase = _Phase.home;
  ScanReport? _report;
  int _scanned = 0;
  int _total = 0;
  String _currentApp = '';
  int _freedBytes = 0;
  bool _cleaned = false;
  bool _cleaning = false;

  // Scan animation ke liye.
  late final AnimationController _anim;
  final _rand = math.Random(42);

  @override
  void initState() {
    super.initState();
    _anim = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    )..repeat();
  }

  @override
  void dispose() {
    _anim.dispose();
    super.dispose();
  }

  Future<void> _startScan() async {
    // Storage permission (badi/duplicate files ke liye). Na mile to bhi
    // apps ka scan chalega — files wala hissa khaali rahega.
    var scanFiles = true;
    try {
      final status = await Permission.storage.request();
      if (!status.isGranted) {
        final photos = await Permission.photos.request();
        final videos = await Permission.videos.request();
        scanFiles = photos.isGranted || videos.isGranted;
      }
    } catch (_) {
      scanFiles = false;
    }

    setState(() {
      _phase = _Phase.scanning;
      _scanned = 0;
      _total = 0;
      _currentApp = '';
      _report = null;
      _freedBytes = 0;
      _cleaned = false;
    });
    await SoundService.instance.playScan();

    final report = await ScanService.runScan(
      scanFiles: scanFiles,
      onProgress: (done, total, appName) {
        if (!mounted) return;
        setState(() {
          _scanned = done;
          _total = total;
          _currentApp = appName;
        });
      },
    );

    if (!mounted) return;
    setState(() {
      _report = report;
      _phase = _Phase.result;
    });
    if (report.dangerous.isNotEmpty) {
      await SoundService.instance.playAlert();
    }
  }

  Future<void> _clean() async {
    if (_report == null || _cleaning) return;
    setState(() => _cleaning = true);

    var freed = await ScanService.cleanOwnCache();
    final filesToDelete = <FoundFile>[
      ..._report!.largeFiles,
      for (final g in _report!.duplicateGroups) ...g.skip(1),
    ];
    if (filesToDelete.isNotEmpty) {
      freed += await ScanService.deleteFiles(filesToDelete);
    }

    await SoundService.instance.playClean();
    if (!mounted) return;
    setState(() {
      _freedBytes = freed;
      _cleaned = true;
      _cleaning = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Virus Cleaner'),
        actions: const [
          Padding(
            padding: EdgeInsets.only(right: 16),
            child: Center(
              child: Text(
                'v$kAppVersion',
                style: TextStyle(fontSize: 13),
              ),
            ),
          ),
        ],
      ),
      body: switch (_phase) {
        _Phase.home => _buildHome(),
        _Phase.scanning => _buildScanning(),
        _Phase.result => _buildResult(),
      },
    );
  }

  // ------------------------------- HOME ------------------------------------
  Widget _buildHome() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const SizedBox(height: 12),
          const Icon(Icons.shield, size: 110, color: Color(0xFF1B5E20)),
          const SizedBox(height: 8),
          const Text(
            'Virus Cleaner',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 32,
              fontWeight: FontWeight.bold,
              color: Color(0xFF1B5E20),
            ),
          ),
          const SizedBox(height: 4),
          const Text(
            'Phone ki asal safai aur jaanch',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 17, color: Colors.black54),
          ),
          const SizedBox(height: 28),
          ElevatedButton.icon(
            onPressed: _startScan,
            icon: const Icon(Icons.search, size: 28),
            label: const Text('SCAN KAREIN'),
          ),
          const SizedBox(height: 20),
          _infoCard(const [
            '• Installed apps ki asal jaanch — mashhoor kharab packages aur khatarnak permissions.',
            '• Apni cache aur badi/duplicate files ki safai.',
            '• Kharab app mile to uninstall aap khud system se confirm karke karenge.',
            '• Agar kuch na mile to saaf likha hoga: "Koi virus nahi mila".',
          ]),
          const SizedBox(height: 12),
          const Text(
            'Ye app antivirus engine nahi hai aur 100% guarantee nahi deti — '
            'ye sirf mashhoor kharab packages aur shakki permissions check karti hai.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 13, color: Colors.black45),
          ),
        ],
      ),
    );
  }

  Widget _infoCard(List<String> lines) {
    return Card(
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            for (final line in lines)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Text(line, style: const TextStyle(fontSize: 15)),
              ),
          ],
        ),
      ),
    );
  }

  // ----------------------------- SCANNING ----------------------------------
  Widget _buildScanning() {
    final progress = _total > 0 ? _scanned / _total : 0.0;
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // NOTE: Ye animation SIRF dikhane ke liye hai — asal scan neeche
          // progress bar aur app ke naam se chal raha hai. Virus ke nishan
          // khinch kar shield mein jaate dikhte hain; is ka matlab ye NAHI
          // ke screen par asal virus hain.
          SizedBox(
            height: 220,
            child: AnimatedBuilder(
              animation: _anim,
              builder: (context, _) => CustomPaint(
                painter: _VirusPullPainter(
                  progress: _anim.value,
                  rand: _rand,
                ),
                child: const Center(
                  child: Icon(Icons.shield, size: 96, color: Color(0xFF1B5E20)),
                ),
              ),
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'Ye animation sirf dikhane ke liye hai — asal scan chal raha hai',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 12, color: Colors.black45),
          ),
          const SizedBox(height: 20),
          LinearProgressIndicator(
            value: progress,
            minHeight: 10,
            backgroundColor: Colors.green.shade100,
            color: const Color(0xFF1B5E20),
          ),
          const SizedBox(height: 12),
          Text(
            _total > 0 ? '$_scanned / $_total apps' : 'Apps gin rahe hain...',
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 6),
          Text(
            _currentApp,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 14, color: Colors.black54),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }

  // ------------------------------ RESULT -----------------------------------
  Widget _buildResult() {
    final r = _report!;
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          if (!r.foundAnything) ...[
            const Icon(Icons.verified, size: 100, color: Color(0xFF1B5E20)),
            const SizedBox(height: 8),
            const Text(
              'Koi virus nahi mila',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 26,
                fontWeight: FontWeight.bold,
                color: Color(0xFF1B5E20),
              ),
            ),
            const SizedBox(height: 6),
            Text(
              '${r.totalApps} apps jaanchi gayin — koi mashhoor kharab app ya '
              'shakki permission nahi mili. Phone saaf hai.',
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 15, color: Colors.black54),
            ),
          ] else ...[
            if (r.dangerous.isNotEmpty) ...[
              const Icon(Icons.warning_amber_rounded,
                  size: 90, color: Colors.red),
              const Text(
                'Khatarnak apps mili hain!',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.red,
                ),
              ),
            ] else ...[
              const Icon(Icons.warning_amber_rounded,
                  size: 90, color: Colors.orange),
              const Text(
                'Kuch shakki cheezein mili hain',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: Colors.orange,
                ),
              ),
            ],
          ],
          const SizedBox(height: 16),
          _summaryRow(r),
          const SizedBox(height: 16),
          if (r.dangerous.isNotEmpty) ...[
            const _SectionTitle('Khatarnak — foran uninstall karein'),
            for (final app in r.dangerous) _appCard(app, dangerous: true),
          ],
          if (r.suspicious.isNotEmpty) ...[
            const _SectionTitle('Shakki — dekh kar faisla karein'),
            for (final app in r.suspicious) _appCard(app),
          ],
          if (r.ownCacheBytes > 0 || r.largeFiles.isNotEmpty) ...[
            const _SectionTitle('Kachra / bari files'),
            Card(
              child: ListTile(
                leading: const Icon(Icons.delete_sweep),
                title: Text('Apni cache: ${formatMb(r.ownCacheBytes)}'),
                subtitle: const Text(
                    'Sirf is app ki apni cache saaf hogi — doosri apps ki '
                    'cache Android humein saaf karne nahi deta.'),
              ),
            ),
            for (final f in r.largeFiles)
              Card(
                child: ListTile(
                  leading: const Icon(Icons.insert_drive_file),
                  title: Text(f.name,
                      maxLines: 1, overflow: TextOverflow.ellipsis),
                  subtitle: Text(formatMb(f.sizeBytes)),
                ),
              ),
            if (r.duplicateGroups.isNotEmpty)
              Card(
                child: ListTile(
                  leading: const Icon(Icons.copy),
                  title: Text(
                      '${r.duplicateGroups.length} duplicate groups mili hain'),
                  subtitle: const Text(
                      'Aik jaisi files — safai par aik copy reh jayegi.'),
                ),
              ),
          ],
          const SizedBox(height: 8),
          ElevatedButton.icon(
            onPressed: _cleaning ? null : _clean,
            icon: const Icon(Icons.cleaning_services),
            label: Text(_cleaning ? 'Saaf ho raha hai...' : 'SAF KAREIN'),
          ),
          if (_cleaned) ...[
            const SizedBox(height: 12),
            Card(
              color: Colors.green.shade50,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Text(
                  'Saaf ho gaya: ${formatMb(_freedBytes)} asal mein saaf hua.',
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF1B5E20)),
                ),
              ),
            ),
          ],
          const SizedBox(height: 12),
          OutlinedButton(
            onPressed: _startScan,
            child: const Text('Dobara Scan Karein'),
          ),
          const SizedBox(height: 8),
          TextButton(
            onPressed: () => setState(() => _phase = _Phase.home),
            child: const Text('Wapas Home'),
          ),
        ],
      ),
    );
  }

  Widget _summaryRow(ScanReport r) {
    return Row(
      children: [
        _stat('${r.totalApps}', 'Kul Apps', Colors.black87),
        _stat('${r.dangerous.length}', 'Khatarnak', Colors.red),
        _stat('${r.suspicious.length}', 'Shakki', Colors.orange),
        _stat(formatMb(r.ownCacheBytes), 'Cache', Colors.black87),
      ],
    );
  }

  Widget _stat(String value, String label, Color color) {
    return Expanded(
      child: Card(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 12),
          child: Column(
            children: [
              Text(value,
                  style: TextStyle(
                      fontSize: 20, fontWeight: FontWeight.bold, color: color)),
              Text(label, style: const TextStyle(fontSize: 13)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _appCard(ScannedApp app, {bool dangerous = false}) {
    return Card(
      color: dangerous ? Colors.red.shade50 : Colors.orange.shade50,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  dangerous ? Icons.bug_report : Icons.help_outline,
                  color: dangerous ? Colors.red : Colors.orange,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    app.appName,
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
            Text(app.packageName,
                style: const TextStyle(fontSize: 12, color: Colors.black54)),
            const SizedBox(height: 6),
            for (final reason in app.reasons)
              Text('• $reason', style: const TextStyle(fontSize: 14)),
            const SizedBox(height: 8),
            Row(
              children: [
                ElevatedButton(
                  onPressed: () async {
                    // System uninstall screen — user khud confirm karega.
                    // Android kisi app ko bina user ki haan ke doosri app
                    // delete karne nahi deta.
                    await DeviceApps.uninstallApp(app.packageName);
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor:
                        dangerous ? Colors.red : const Color(0xFF1B5E20),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 10),
                    textStyle: const TextStyle(fontSize: 15),
                  ),
                  child: const Text('Uninstall Karein'),
                ),
                const SizedBox(width: 8),
                OutlinedButton(
                  onPressed: () async {
                    // App Info khulta hai — wahan se cache saaf kar sakte hain.
                    await DeviceApps.openAppSettings(app.packageName);
                  },
                  child: const Text('App Info'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle(this.text);
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 8, bottom: 6),
      child: Text(
        text,
        style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Color(0xFF1B5E20)),
      ),
    );
  }
}

/// Scan animation: virus ke nishan (chhote rang-birange gol daagh) kinaron se
/// beech wale shield ki taraf "khinchte" hue dikhte hain.
///
/// SIRF VISUAL HAI — is animation ka asal scan se koi taaluq nahi. Asal scan
/// progress bar aur app ke naam se dikhaya jata hai.
class _VirusPullPainter extends CustomPainter {
  _VirusPullPainter({required this.progress, required this.rand});

  final double progress; // 0..1, loop hota hai
  final math.Random rand;

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    for (var i = 0; i < 9; i++) {
      // Har nishan ka apna zawiya aur raftaar.
      final angle = (i * 40.0) * math.pi / 180.0;
      final speed = 0.55 + (i % 3) * 0.15;
      final t = (progress * speed + i * 0.11) % 1.0;
      final startR = size.width * 0.48;
      final r = startR * (1 - t);
      final pos = center + Offset(math.cos(angle), math.sin(angle)) * r;
      final radius = 14.0 * (1 - t * 0.6);
      final paint = Paint()
        ..color = (i % 2 == 0
                ? Colors.redAccent
                : Colors.deepPurpleAccent)
            .withOpacity(0.85 * (1 - t * 0.5));
      canvas.drawCircle(pos, radius, paint);
      // Kantay (spikes) — virus jaisa nishan.
      final spike = Paint()
        ..color = paint.color
        ..strokeWidth = 2.5;
      for (var s = 0; s < 6; s++) {
        final a = angle + s * math.pi / 3;
        canvas.drawLine(
          pos + Offset(math.cos(a), math.sin(a)) * radius,
          pos + Offset(math.cos(a), math.sin(a)) * (radius + 7),
          spike,
        );
      }
    }
  }

  @override
  bool shouldRepaint(_VirusPullPainter old) =>
      old.progress != progress;
}
