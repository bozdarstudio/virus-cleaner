// Risk engine — PURE Dart, koi plugin nahi, is liye unit-test ho sakta hai.
//
// IMAANDARI KA LOCK (sakht):
// - Ye engine koi "virus scanner" nahi hai. Ye sirf do asal cheezein check
//   karta hai: (1) mashhoor kharab packages ki fehrist, (2) khatarnak
//   permissions + install ka zariya. Is se zyada ka daawa UI mein kahin
//   NAHI karna — na "100% virus-free", na koi guarantee.
// - Agar kuch na mile to natija hai: "Koi virus nahi mila". Kabhi jhooti
//   ginti ya fake virus NAHI dikhana.

/// Khatre ki satah.
enum RiskLevel {
  /// Sab theek — koi shak wali baat nahi mili.
  safe,

  /// Shakki — Play Store se install nahi, ya khatarnak permissions hain.
  /// User khud dekh kar faisla kare.
  suspicious,

  /// Khatarnak — mashhoor malware package ya spyware jaisa pattern.
  /// Foran uninstall ki salah.
  dangerous,
}

/// Ek installed app ki jaanch ka natija.
class ScannedApp {
  const ScannedApp({
    required this.packageName,
    required this.appName,
    required this.systemApp,
    required this.installer,
    required this.permissions,
    required this.deviceAdmin,
    required this.apkSizeBytes,
    required this.risk,
    required this.reasons,
  });

  final String packageName;
  final String appName;
  final bool systemApp;

  /// Kis app ne install kiya (Play Store = com.android.vending).
  /// Null matlab pata nahi / sideload.
  final String? installer;
  final List<String> permissions;
  final bool deviceAdmin;
  final int apkSizeBytes;
  final RiskLevel risk;

  /// Roman Urdu mein wajahain — user ko dikhane ke liye.
  final List<String> reasons;

  bool get isDangerous => risk == RiskLevel.dangerous;
  bool get isSuspicious => risk == RiskLevel.suspicious;
}

/// Mashhoor kharab packages.
///
/// ZARAAYE (public security reports — Google ne in apps ko Play Store se
/// hataya tha; user ke phone par ab bhi maujood ho sakti hain):
/// - Zscaler ThreatLabz, "Joker, Facestealer & Coper Banking Malware on
///   Google Play" (2022) — Joker downloader apps.
/// - CSIS Tech Blog, "Analysis of Joker — A Spy & Premium Subscription Bot
///   on GooglePlay" (2019) — Joker ke pehle 24 apps.
/// - Zscaler ThreatLabz, "Joker Joking in Google Play" (2021).
///
/// YE FEHRIST MUKAMMAL NAHI HAI — naye malware roz aate hain. Is liye
/// blocklist ke saath permissions wali jaanch bhi lazmi hai.
const Map<String, String> kKnownBadPackages = {
  // Zscaler ThreatLabz 2022 — Joker downloader apps.
  'com.wuwan.pdfscan': 'Simple Note Scanner — Joker malware (Zscaler 2022)',
  'com.unpdf.scan.read.docscanuniver':
      'Universal PDF Scanner — Joker malware (Zscaler 2022)',
  'com.recollect.linkus': 'Private Messenger — Joker malware (Zscaler 2022)',
  'com.premium.put.trustsms': 'Premium SMS — Joker malware (Zscaler 2022)',
  'com.toukyoursms.timemessages':
      'Smart Messages — Joker malware (Zscaler 2022)',
  'messenger.itext.emoji.mesenger':
      'Text Emoji SMS — Joker malware (Zscaler 2022)',
  'com.bloodpressurechecker.tangjiang':
      'Blood Pressure Checker — Joker malware (Zscaler 2022)',
  'exazth.message.send.text.sms': 'Send SMS — Joker malware (Zscaler 2022)',
  'com.sbdlsms.crazymessager.mmsrec':
      'Instant Messenger — Joker malware (Zscaler 2022)',
  'com.sms.mms.message.ffei.free':
      'Smart SMS Messages — Joker malware (Zscaler 2022)',
  'con.sms.fancy': 'Fancy SMS — Joker malware (Zscaler 2022)',
  'com.maskteslary.messages': 'Chat SMS — Joker malware (Zscaler 2022)',
  'sms.ienjoy.joysms.message': 'Enjoy Message — Joker malware (Zscaler 2022)',
  // Joker ka nakli Play Store payload.
  'com.fromtoo2': 'Nakli Play Store — Joker payload (Zscaler 2022)',
  // CSIS 2019 — Joker ke pehle apps.
  'com.with.nofear.myheart': 'Joker malware (CSIS 2019)',
  'com.certain.icdesktop.wallpaper': 'Joker malware (CSIS 2019)',
  'com.building.castle.bster': 'Joker malware (CSIS 2019)',
  'com.futureage.facelook': 'Joker malware (CSIS 2019)',
  'com.comeback.myside.sms': 'Joker malware (CSIS 2019)',
  'com.sybo.ggp.cam': 'Joker malware (CSIS 2019)',
  'com.declare.smsarr.message': 'Joker malware (CSIS 2019)',
  'com.Climate.sms': 'Joker malware (CSIS 2019)',
  'com.xw.supervpnfree': 'Joker malware (CSIS 2019)',
  'com.vegtable.blif.camera': 'Joker malware (CSIS 2019)',
  'com.print.plant.scan': 'Joker malware (CSIS 2019)',
};

/// Play Store ka installer package.
const String kPlayStoreInstaller = 'com.android.vending';

/// Wo permissions jo aam app ko nahi chahiye — spyware/adware ki nishani.
const Set<String> kDangerousPermissions = {
  'android.permission.SEND_SMS',
  'android.permission.READ_SMS',
  'android.permission.RECEIVE_SMS',
  'android.permission.READ_CALL_LOG',
  'android.permission.READ_CONTACTS',
  'android.permission.SYSTEM_ALERT_WINDOW', // doosri apps ke upar dikhana
  'android.permission.BIND_DEVICE_ADMIN', // device admin
  'android.permission.BIND_ACCESSIBILITY_SERVICE',
  'android.permission.REQUEST_INSTALL_PACKAGES', // khud apps install karna
};

/// Aik app ki risk jaanch — pure function, unit-test ke liye.
ScannedApp assessApp({
  required String packageName,
  required String appName,
  required bool systemApp,
  required String? installer,
  required List<String> permissions,
  required bool deviceAdmin,
  required int apkSizeBytes,
}) {
  final reasons = <String>[];
  var risk = RiskLevel.safe;

  // 1) Mashhoor kharab package?
  final badNote = kKnownBadPackages[packageName];
  if (badNote != null) {
    return ScannedApp(
      packageName: packageName,
      appName: appName,
      systemApp: systemApp,
      installer: installer,
      permissions: permissions,
      deviceAdmin: deviceAdmin,
      apkSizeBytes: apkSizeBytes,
      risk: RiskLevel.dangerous,
      reasons: ['Mashhoor malware hai — $badNote'],
    );
  }

  // System apps ko sakhti se nahi parakhte — wo phone ke saath aati hain.
  // Sirf device-admin wali system app par bhi nazar rakhte hain.
  final dangerousPerms =
      permissions.where(kDangerousPermissions.contains).toList();
  final hasSms = permissions.any((p) => p.contains('_SMS'));
  final hasOverlay =
      permissions.contains('android.permission.SYSTEM_ALERT_WINDOW');

  // 2) Spyware jaisa pattern: device admin + SMS/overlay.
  if (deviceAdmin && (hasSms || hasOverlay)) {
    risk = RiskLevel.dangerous;
    reasons.add('Device Admin hai aur SMS/overlay ki permission bhi — '
        'ye spyware jaisa pattern hai');
  }

  // 3) Install ka zariya: Play Store se nahi?
  final fromPlay = installer == kPlayStoreInstaller;
  final unknownSource = installer == null || !fromPlay;
  if (unknownSource && !systemApp) {
    if (risk == RiskLevel.safe) risk = RiskLevel.suspicious;
    reasons.add(installer == null
        ? 'Pata nahi kahan se install hui (Play Store se nahi)'
        : 'Play Store se install nahi hui — zariya: $installer');
  }

  // 4) Khatarnak permissions.
  if (dangerousPerms.isNotEmpty && !systemApp) {
    if (risk == RiskLevel.safe) risk = RiskLevel.suspicious;
    final short = dangerousPerms
        .map((p) => p.replaceFirst('android.permission.', ''))
        .join(', ');
    reasons.add('Khatarnak permissions hain: $short');
  }

  return ScannedApp(
    packageName: packageName,
    appName: appName,
    systemApp: systemApp,
    installer: installer,
    permissions: permissions,
    deviceAdmin: deviceAdmin,
    apkSizeBytes: apkSizeBytes,
    risk: risk,
    reasons: reasons,
  );
}

/// MB ko insanon wali shakal mein likho.
String formatMb(int bytes) {
  if (bytes < 1024) return '$bytes B';
  if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(0)} KB';
  return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
}
