package com.bozdar.viruscleaner

import android.app.admin.DevicePolicyManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

/**
 * Native channel: com.bozdar.viruscleaner/native
 *
 * Method `getAppDetails` (args: packageName) — PackageManager ki ASAL
 * maloomat deta hai:
 *   - permissions: app ne jo permissions mangi hain
 *   - installer: kis app ne install kiya (null = pata nahi / sideload)
 *   - deviceAdmin: kya ye app device admin hai
 *
 * Method `getInstalledApps` (koi args nahi) — saari installed apps ki list:
 *   packageName, appName (label), systemApp, apkFilePath.
 *
 * Method `uninstallApp` (args: packageName) — system uninstall screen
 * kholta hai (ACTION_DELETE); user khud confirm karega.
 *
 * Method `openAppSettings` (args: packageName) — App Info settings kholta
 * hai (cache saaf karne ke liye).
 *
 * Koi permission yahan se nahi mangi jati, koi app yahan se delete nahi
 * hoti — sirf parhna (read-only) aur system screens kholna.
 */
class MainActivity : FlutterActivity() {
    private val channelName = "com.bozdar.viruscleaner/native"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            channelName
        ).setMethodCallHandler { call, result ->
            when (call.method) {
                "getAppDetails" -> {
                    val pkg = call.argument<String>("packageName")
                    if (pkg.isNullOrEmpty()) {
                        result.error("BAD_ARGS", "packageName missing", null)
                        return@setMethodCallHandler
                    }
                    result.success(getAppDetails(pkg))
                }
                "getInstalledApps" -> {
                    result.success(getInstalledApps())
                }
                "uninstallApp" -> {
                    val pkg = call.argument<String>("packageName")
                    if (pkg.isNullOrEmpty()) {
                        result.error("BAD_ARGS", "packageName missing", null)
                        return@setMethodCallHandler
                    }
                    result.success(uninstallApp(pkg))
                }
                "openAppSettings" -> {
                    val pkg = call.argument<String>("packageName")
                    if (pkg.isNullOrEmpty()) {
                        result.error("BAD_ARGS", "packageName missing", null)
                        return@setMethodCallHandler
                    }
                    result.success(openAppSettings(pkg))
                }
                else -> result.notImplemented()
            }
        }
    }

    private fun getAppDetails(pkg: String): Map<String, Any?> {
        val pm: PackageManager = packageManager
        val permissions = mutableListOf<String>()
        var installer: String? = null
        var deviceAdmin = false

        try {
            @Suppress("DEPRECATION")
            val info = pm.getPackageInfo(pkg, PackageManager.GET_PERMISSIONS)
            info.requestedPermissions?.let { permissions.addAll(it) }
        } catch (_: PackageManager.NameNotFoundException) {
            // App nahi mili — khaali maloomat wapas.
        }

        try {
            installer = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                pm.getInstallSourceInfo(pkg).installingPackageName
            } else {
                @Suppress("DEPRECATION")
                pm.getInstallerPackageName(pkg)
            }
        } catch (_: Exception) {
            installer = null
        }

        try {
            val dpm =
                getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            deviceAdmin = dpm.activeAdmins?.any { it.packageName == pkg } == true
        } catch (_: Exception) {
            deviceAdmin = false
        }

        return mapOf(
            "permissions" to permissions,
            "installer" to installer,
            "deviceAdmin" to deviceAdmin
        )
    }

    /**
     * Saari installed apps ki list — PackageManager ki ASAL maloomat.
     * QUERY_ALL_PACKAGES permission manifest mein hai, is liye Android 11+
     * par bhi poori list milti hai. Har app: packageName, label, systemApp,
     * apkFilePath (APK ka size Dart taraf se nikala jata hai).
     */
    private fun getInstalledApps(): List<Map<String, Any?>> {
        val pm: PackageManager = packageManager
        val out = mutableListOf<Map<String, Any?>>()
        try {
            @Suppress("DEPRECATION")
            val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            for (ai in apps) {
                val label = try {
                    pm.getApplicationLabel(ai).toString()
                } catch (_: Exception) {
                    ai.packageName
                }
                val systemApp = (ai.flags and
                    android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0
                out.add(
                    mapOf(
                        "packageName" to ai.packageName,
                        "appName" to label,
                        "systemApp" to systemApp,
                        "apkFilePath" to (ai.sourceDir ?: "")
                    )
                )
            }
        } catch (_: Exception) {
            // Kuch ghalat ho to khaali list — scan rukega nahi.
        }
        return out
    }

    /**
     * System uninstall screen kholo (ACTION_DELETE). User khud confirm
     * karega — Android kisi app ko bina user ki haan ke doosri app
     * delete karne nahi deta.
     */
    private fun uninstallApp(pkg: String): Boolean {
        return try {
            val intent = android.content.Intent(
                android.content.Intent.ACTION_DELETE,
                android.net.Uri.parse("package:$pkg")
            )
            startActivity(intent)
            true
        } catch (_: Exception) {
            false
        }
    }

    /**
     * App Info (system settings) kholo — wahan se cache saaf kar sakte hain.
     */
    private fun openAppSettings(pkg: String): Boolean {
        return try {
            val intent = android.content.Intent(
                android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                android.net.Uri.parse("package:$pkg")
            )
            startActivity(intent)
            true
        } catch (_: Exception) {
            false
        }
    }
}
