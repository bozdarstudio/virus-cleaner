package com.bozdar.viruscleaner

import android.app.admin.DevicePolicyManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

/**
 * Native channel: com.bozdar.viruscleaner/native
 *
 * Method `getAppDetails` (args: packageName) — PackageManager ki ASAL
 * maloomat deta hai:
 *   - permissions: app ne jo permissions mangi hain
 *   - installer: kis app ne install kiya (null = pata nahi / sideload)
 *   - deviceAdmin: kya ye app device admin hai
 *
 * Koi permission yahan se nahi mangi jati, koi app yahan se delete nahi
 * hoti — sirf parhna (read-only).
 */
class MainActivity : FlutterActivity() {
    private val channelName = "com.bozdar.viruscleaner/native"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            channelName
        ).setMethodCallHandler { call, result ->
            if (call.method == "getAppDetails") {
                val pkg = call.argument<String>("packageName")
                if (pkg.isNullOrEmpty()) {
                    result.error("BAD_ARGS", "packageName missing", null)
                    return@setMethodCallHandler
                }
                result.success(getAppDetails(pkg))
            } else {
                result.notImplemented()
            }
        }
    }

    private fun getAppDetails(pkg: String): Map<String, Any?> {
        val pm: PackageManager = packageManager
        val permissions = mutableListOf<String>()
        var installer: String? = null
        var deviceAdmin = false

        try {
            @Suppress("DEPRECATION")
            val info = pm.getPackageInfo(pkg, PackageManager.GET_PERMISSIONS)
            info.requestedPermissions?.let { permissions.addAll(it) }
        } catch (_: PackageManager.NameNotFoundException) {
            // App nahi mili — khaali maloomat wapas.
        }

        try {
            installer = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                pm.getInstallSourceInfo(pkg).installingPackageName
            } else {
                @Suppress("DEPRECATION")
                pm.getInstallerPackageName(pkg)
            }
        } catch (_: Exception) {
            installer = null
        }

        try {
            val dpm =
                getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            deviceAdmin = dpm.activeAdmins?.any { it.packageName == pkg } == true
        } catch (_: Exception) {
            deviceAdmin = false
        }

        return mapOf(
            "permissions" to permissions,
            "installer" to installer,
            "deviceAdmin" to deviceAdmin
        )
    }
}
