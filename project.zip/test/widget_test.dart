import 'package:flutter_test/flutter_test.dart';
import 'package:viruscleaner/main.dart';

void main() {
  testWidgets('Home dikhta hai — SCAN button maujood', (tester) async {
    await tester.pumpWidget(const VirusCleanerApp());
    expect(find.text('Virus Cleaner'), findsWidgets);
    expect(find.text('SCAN KAREIN'), findsOneWidget);
    expect(find.text('v1.0.0'), findsOneWidget);
  });
}
