import 'package:flutter_test/flutter_test.dart';
import 'package:viruscleaner/risk.dart';

void main() {
  group('assessApp — risk engine', () {
    test('mashhoor kharab package (Joker) = dangerous', () {
      final app = assessApp(
        packageName: 'com.wuwan.pdfscan',
        appName: 'Simple Note Scanner',
        systemApp: false,
        installer: 'com.android.vending',
        permissions: const [],
        deviceAdmin: false,
        apkSizeBytes: 1000,
      );
      expect(app.risk, RiskLevel.dangerous);
      expect(app.reasons.first, contains('Joker'));
    });

    test('Play Store ki aam app = safe', () {
      final app = assessApp(
        packageName: 'com.example.notes',
        appName: 'Notes',
        systemApp: false,
        installer: 'com.android.vending',
        permissions: const ['android.permission.INTERNET'],
        deviceAdmin: false,
        apkSizeBytes: 1000,
      );
      expect(app.risk, RiskLevel.safe);
      expect(app.reasons, isEmpty);
    });

    test('sideload + SMS permission = suspicious', () {
      final app = assessApp(
        packageName: 'com.example.smsapp',
        appName: 'SMS App',
        systemApp: false,
        installer: null,
        permissions: const ['android.permission.READ_SMS'],
        deviceAdmin: false,
        apkSizeBytes: 1000,
      );
      expect(app.risk, RiskLevel.suspicious);
      expect(app.reasons.length, greaterThanOrEqualTo(2));
    });

    test('device admin + SMS = dangerous (spyware pattern)', () {
      final app = assessApp(
        packageName: 'com.example.spy',
        appName: 'Spy',
        systemApp: false,
        installer: 'com.android.vending',
        permissions: const [
          'android.permission.READ_SMS',
          'android.permission.SYSTEM_ALERT_WINDOW',
        ],
        deviceAdmin: true,
        apkSizeBytes: 1000,
      );
      expect(app.risk, RiskLevel.dangerous);
    });

    test('system app ko permissions par shakki nahi kehte', () {
      final app = assessApp(
        packageName: 'com.android.phone',
        appName: 'Phone',
        systemApp: true,
        installer: null,
        permissions: const [
          'android.permission.READ_CALL_LOG',
          'android.permission.READ_CONTACTS',
        ],
        deviceAdmin: false,
        apkSizeBytes: 1000,
      );
      expect(app.risk, RiskLevel.safe);
    });

    test('blocklist mein sirf asal mashhoor packages hain', () {
      expect(kKnownBadPackages.length, greaterThanOrEqualTo(20));
      expect(kKnownBadPackages.containsKey('com.fromtoo2'), isTrue);
    });
  });

  group('formatMb', () {
    test('bytes / KB / MB', () {
      expect(formatMb(500), '500 B');
      expect(formatMb(2048), '2 KB');
      expect(formatMb(3 * 1024 * 1024), '3.0 MB');
    });
  });
}
